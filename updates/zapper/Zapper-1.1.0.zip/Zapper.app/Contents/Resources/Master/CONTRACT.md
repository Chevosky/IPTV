# Contrato maestro v1.0.0

## Formato e identidad

`master-catalog-v1.json` es el documento completo. `snapshot-252.json` es una proyección ordenada de referencias, ligada al SHA-256 del maestro. Las listas M3U son exportaciones futuras; no definen la identidad.

Schema JSON Schema Draft 2020-12; versión del contrato `1.0.0`. Rechazar versiones desconocidas antes de reemplazar datos. Los schemas fijan estructura; el validador semántico comprueba relaciones, preservación y evidencia. Cambios incompatibles requieren otra versión mayor y migración explícita; no regenerar IDs por cambios de nombre, orden, URL o prioridad.

- `channelId`: conserva exactamente el ID de Phase 1. Identifica el registro editorial; no equivale a disponibilidad.
- `sourceId`: conserva el ID técnico previo. Una fuente puede tener varias asociaciones.
- `bindingId`: `binding_` + primeros 24 caracteres hex del SHA-256 de `channelId + NUL + sourceId`. Une una señal exacta y una fuente; su identidad no depende de prioridad.
- `identities`, `identityAliases`, `historicalAliases`: referencias trazables. Los aliases de presentación no autorizan consolidación. Un YouTube channelId identifica un publicador; por sí solo no demuestra una señal regional exacta.
- `entityKind`: distingue LINEAR, EVENT, UNRESOLVED_EVENT_SLOT, VOD_OR_HIGHLIGHT, RESEARCH_SIGNAL y EVENT_FAMILY. Solo LINEAR ingresa a la proyección de canales existente.
- `presentation`: categorías, memberships y metadatos regionales/idiomas originales. No normalizar variantes para fusionarlas.

## Fuentes, prioridades y alternativas

`bindings` conserva todas las asociaciones únicas; `preservedPhase1Bindings` conserva cada observación original, incluidas repeticiones. `preservedPhase1Source` y `preservedPhase1Record` preservan íntegramente los datos anteriores.

`primaryBindingId` mantiene la selección existente de la candidata. `priority` conserva la prioridad explícita original o null; `preservationOrder` es orden de conservación y no una evaluación de calidad. Todas las otras fuentes permanecen como KNOWN_ALTERNATIVE. Ninguna alternativa se elimina por quedar temporalmente caída o por no ser compatible con Flex.

`configuration`: adapterId, executionMode, locatorKind, headers y definitionRef. PLUTO_UUID requiere resolver; RESOLVER_PAGE requiere un adapter de extracción/resolución, no puede enviarse a AVPlayer como HLS. ORIGIN_PAGE/REFERENCE_ONLY no son URLs de video. Los locators confidenciales quedan referenciados por archivo/selector/hash; nunca usar el texto REDACTED como URL. El consumidor de referencia demuestra hidratación local en memoria sin imprimir el valor.

## Estados independientes

Identificación, verificación histórica, integración Zapper, publicación Flex, compatibilidad y disponibilidad son campos separados. Todos los estados actuales de este snapshot son UNKNOWN: no se ejecutaron nuevas pruebas de reproducción. UNKNOWN no revoca por sí solo las fuentes de la candidata; impide afirmar un PASS vigente.

Para un futuro PASS vigente: checkedAtUTC y validUntilUTC conscientes de zona, ventana no vencida, referencias de evidencia existentes. Al menos una evidencia debe tener temporalStatus CURRENT_VERIFIED, recordedAtUTC igual al checkedAtUTC, observation.subject con el identificador exacto del objeto y observation.criteria con identityVerified, videoVerified, audioVerified, playheadAdvanced y sustainedPlayback verdaderos. El validador comprueba metadatos; no demuestra autenticidad física de una prueba. La infraestructura que genere evidencia debe medir estos criterios realmente.

`automaticFallback` permanece desactivado. Habilitarlo exige infrastructureProven y referencias de evidencia; este contrato no implementa failover ni demuestra infraestructura. Compatibilidad histórica o declarada no constituye prueba actual.

## EPG

262 bindings: 237 CATALOG_DECLARED y 25 RESEARCH_CANDIDATE. Ninguno se eleva a VERIFIED_SIGNAL_MATCH en esta fase. EPG tiene su propio ID, xmltvId/guideURL si conocidos, provenance y estado. No generar programación para eventos sin metadata comprobada. La URL declarada no constituye prueba de descarga o correspondencia del programa con la señal.

## Preservación y activación

El maestro contiene 1469 registros y 1512 fuentes, no 1469 canales reproducibles. initialProjection contiene únicamente las 252 entradas existentes. Las ocho Experimental y las recuperaciones YouTube/investigadas permanecen fuera de esa proyección; automaticallyActivateRecovery=false. Los 1120 slots Sports se conservan como ledger editorial, sin convertir eventos o slots no resueltos en canales operativos. Los 117 grupos ambiguos siguen pendientes de revisión, sin nuevas fusiones.

## Fuentes oficiales del formato

- JSON Schema validation Draft 2020-12: https://json-schema.org/draft/2020-12/json-schema-validation
- Referencias y estructura de schemas: https://json-schema.org/understanding-json-schema/structuring
- Identidad YouTube channel: https://developers.google.com/youtube/v3/docs/channels
- Metadatos de emisiones YouTube: https://developers.google.com/youtube/v3/docs/videos#liveStreamingDetails

Estas fuentes documentan formatos/identificadores; no acreditan reproducción de nuestros canales.
