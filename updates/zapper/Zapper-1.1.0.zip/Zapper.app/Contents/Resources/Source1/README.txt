SOURCE 1 — STRUCTURED CATALOG EXPORT

This package contains the authoritative structured exports recovered from the prior source investigation.

FILES
- master-catalog-v0.3.json
  Master catalog: original rows, scopes, categories, names, endpoints and historical catalog statuses.

- content-map-v1.json
  Content identity layer: content_id, content kind, canonical labels, source associations, unresolved event slots and relation evidence.

- source-map-v2.json
  Technical source identity layer: source_id, endpoint identity, categories/scopes, current source state and evidence.

- runtime-registry-v1.json
  Runtime execution layer: execution_mode, selectable state, retry policy, content runtime routing and unresolved event pool routing.

- adapter-manifest-v1.json
  Adapter layer: source_id -> adapter_id / execution engine mapping and adapter profiles.

CORE INVARIANTS
- Master rows: 1343
- Effective catalog entries: 1340
- Technical source IDs: 1163
- Resolved content IDs: 606
- Unresolved event slots: 514
- Executable source IDs classified: 106
- Execution modes include DIRECT_URL, RESOLVE_THEN_PLAY and BROWSER_EMBED, plus non-executable states.

IMPORTANT
- content_id <-> source_id is many-to-many.
- source_id.execution_mode is authoritative; do not infer strategy from hostname.
- NOT_TESTED_NOW does not mean unavailable.
- Unresolved event slots remain separate and require runtime content matching.
- Do not rewrite catalog URLs or silently reclassify historical states.

PRIVACY NEUTRALIZATION
The structural data is preserved. Only four metadata strings that named the external source were neutralized to "Source1"; no IDs, URLs, categories, statuses, associations, endpoints or execution classifications were changed.
